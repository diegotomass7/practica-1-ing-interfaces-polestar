# Polestar para Windows

Extrae el ZIP completo y abre Polestar.exe. Si Windows solicita .NET, instala el **Runtime de escritorio de .NET 8** para tu equipo desde Microsoft.

https://dotnet.microsoft.com/download/dotnet/8.0

Cuenta ficticia de prueba: cliente@example.com / PolestarDemo1.
